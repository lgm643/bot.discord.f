"""La Mystic Discord bot."""
